# README #

This README would normally document whatever steps are necessary to get your application up and running.

## APP KODI LOG ###
MAC ~/Library/Logs/kodi.log
WINDOWS %appdata%/roaming/kodi/kodi.log

### APP DATA STRUCTURE ###
Android	Android/data/org.xbmc.kodi/files/.kodi/userdata/
iOS	/private/var/mobile/Library/Preferences/Kodi/userdata/
Linux	~/.kodi/userdata/
Mac	/Users/<your_user_name>/Library/Application Support/Kodi/userdata/
OpenELEC	/storage/.kodi/userdata/
Windows	Start - type %APPDATA%\kodi\userdata - press <Enter>

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

*Clone the repository in these locations:

Android	Android/data/org.xbmc.kodi/files/.kodi/userdata/
iOS	/private/var/mobile/Library/Preferences/Kodi/userdata/
Linux	~/.kodi/userdata/
Mac	/Users/<your_user_name>/Library/Application Support/Kodi/userdata/
OpenELEC	/storage/.kodi/userdata/
Windows	Start - type %APPDATA%\kodi\userdata - press <Enter>

Then go to addons directory, and work there.

Windows example: %APPDATA%\Kodi\addons\plugin.video.tvmasplus

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact